import React from "react";
import { render } from "react-dom";
import Demo from "./demo";

render(<Demo />, document.getElementById("root"));
